///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  MODIFIED BY: Donald Champagne - CS 330 Final Project (desert sunset scene)
//  AI Acknowledgment: Claude (Anthropic) was used to help troubleshoot texture
//  loading, plan the lighting and object layout, and draft code comments.
//  All code was reviewed, tested, and integrated by Donald Champagne.
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 * 
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method is used for loading the image files used to
 *  texture the objects in the 3D scene. Each texture is
 *  stored with a tag so it can be looked up by name when
 *  a shape is drawn. All textures are from ambientCG
 *  (free CC0 license) at 1024 pixel resolution.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	// bark image for the palm tree trunks (ambientCG Bark012)
	CreateGLTexture("textures/bark.jpg", "bark");

	// leaf image for the palm tree canopies (ambientCG ScatteredLeaves009)
	CreateGLTexture("textures/leaves.jpg", "leaves");

	// sand image for the desert floor plane
	CreateGLTexture("textures/sand.jpg", "sand");

	// stone block image for the pyramids (ambientCG Bricks084)
	CreateGLTexture("textures/stone.jpg", "stone");

	// bind the loaded textures to the OpenGL texture slots
	// (must be called after every CreateGLTexture call)
	BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the material settings
 *  for the objects in the 3D scene. Each material controls how
 *  strongly a surface reflects the diffuse and specular light,
 *  so rough surfaces stay matte and smoother ones show a sheen.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// BARK: rough and dry, so it reflects almost no specular light.
	// The diffuse light does the work of showing the trunk's round shape.
	OBJECT_MATERIAL barkMaterial;
	barkMaterial.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	barkMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	barkMaterial.shininess = 4.0f;
	barkMaterial.tag = "bark";
	m_objectMaterials.push_back(barkMaterial);

	// LEAVES: mostly matte with a very soft highlight, like the
	// slightly waxy surface of a palm frond
	OBJECT_MATERIAL leafMaterial;
	leafMaterial.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	leafMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	leafMaterial.shininess = 8.0f;
	leafMaterial.tag = "leaves";
	m_objectMaterials.push_back(leafMaterial);

	// SAND: fine grains catch the low sun, so the floor gets a
	// moderate specular sheen to show light reflecting off the plane
	OBJECT_MATERIAL sandMaterial;
	sandMaterial.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	sandMaterial.specularColor = glm::vec3(0.35f, 0.35f, 0.35f);
	sandMaterial.shininess = 16.0f;
	sandMaterial.tag = "sand";
	m_objectMaterials.push_back(sandMaterial);

	// STONE: weathered limestone blocks, matte with a faint sheen
	// where the sun hits the flat faces of the pyramids
	OBJECT_MATERIAL stoneMaterial;
	stoneMaterial.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	stoneMaterial.specularColor = glm::vec3(0.15f, 0.15f, 0.15f);
	stoneMaterial.shininess = 8.0f;
	stoneMaterial.tag = "stone";
	m_objectMaterials.push_back(stoneMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is used for adding and configuring the light
 *  sources for the 3D scene. The scene uses two different types
 *  of light: a directional light for the setting sun and a
 *  point light that acts as a cool fill from the evening sky.
 *  Together they light every side of every object, so nothing
 *  goes dark as the camera moves around the scene.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// tell the shaders to render the 3D scene with custom lighting
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// MAIN LIGHT: warm orange sunset (directional light)
	// A directional light hits every object from the same angle, like
	// real sunlight. The direction points from the visible sun (low,
	// behind and to the left of the pyramids) toward the scene, so the
	// back and left faces of each object glow orange. The ambient value
	// keeps every surface from falling into complete shadow.
	m_pShaderManager->setVec3Value("directionalLight.direction", 0.79f, -0.3f, 0.54f);
	m_pShaderManager->setVec3Value("directionalLight.ambient", 0.25f, 0.18f, 0.14f);
	m_pShaderManager->setVec3Value("directionalLight.diffuse", 1.0f, 0.62f, 0.32f);
	m_pShaderManager->setVec3Value("directionalLight.specular", 0.6f, 0.45f, 0.3f);
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);

	// SECONDARY LIGHT: cool blue sky fill (point light)
	// Placed high and in front of the scene, on the opposite side from
	// the sun, so the faces turned toward the camera pick up a soft blue
	// evening tone instead of going dark. The warm and cool contrast
	// helps sell the sunset.
	m_pShaderManager->setVec3Value("pointLights[0].position", 6.0f, 12.0f, 10.0f);
	m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.05f, 0.05f, 0.08f);
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", 0.45f, 0.48f, 0.65f);
	m_pShaderManager->setVec3Value("pointLights[0].specular", 0.15f, 0.15f, 0.2f);
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// load and bind all textures used in the scene
	LoadSceneTextures();
	// define the materials for the objects in the scene
	DefineObjectMaterials();
	// add and configure the light sources for the scene
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadPyramid4Mesh();
}

/***********************************************************
 *  DrawPalmTree()
 *
 *  This method draws one complete palm tree, built from two
 *  basic shapes: a cylinder trunk and a flattened sphere
 *  canopy. Every size and position is calculated from the
 *  "size" value, so the same function can place a big tree
 *  in front and a smaller one farther back without repeating
 *  any of the drawing code.
 *
 *  x, z  - where the base of the trunk sits on the sand
 *  size  - 1.0 is a full size tree, 0.5 is half as tall, etc.
 ***********************************************************/
void SceneManager::DrawPalmTree(float x, float z, float size)
{
	/*** TRUNK (cylinder) ***/
	// the cylinder mesh is built with its base at the origin, so a
	// Y position of 0 stands the trunk directly on the sand
	SetTransformations(
		glm::vec3(0.5f * size, 5.0f * size, 0.5f * size),
		0.0f, 0.0f, 0.0f,
		glm::vec3(x, 0.0f, z));

	SetShaderTexture("bark");
	SetShaderMaterial("bark");

	// COMPLEX TEXTURING TECHNIQUE: TILING
	// The trunk is about 3x taller than it is around, so the bark
	// repeats 3 times along the height to keep the bark plates close
	// to their natural proportions instead of stretching them.
	SetTextureUVScale(1.0f, 3.0f);
	m_basicMeshes->DrawCylinderMesh();

	/*** CANOPY (flattened sphere) ***/
	// sits just below the top of the trunk (4.8 of 5.0) so the two
	// shapes overlap slightly and there is no visible gap
	SetTransformations(
		glm::vec3(1.2f * size, 0.6f * size, 1.2f * size),
		0.0f, 0.0f, 0.0f,
		glm::vec3(x, 4.8f * size, z));

	SetShaderTexture("leaves");
	SetShaderMaterial("leaves");
	// reset the tiling so the trunk's tiling doesn't carry over
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawSphereMesh();
}

/***********************************************************
 *  DrawPyramid()
 *
 *  This method draws one stone pyramid sitting on the sand.
 *  Like DrawPalmTree(), it is reusable: pass in a location and
 *  size and the function handles the transform, texture,
 *  material, and tiling.
 *
 *  x, z       - center of the pyramid's base on the sand
 *  baseWidth  - width of the square base
 *  height     - height from the sand to the tip
 ***********************************************************/
void SceneManager::DrawPyramid(float x, float z, float baseWidth, float height)
{
	// the pyramid mesh is centered on its middle, so it is raised
	// by half its height to make the base rest on the sand
	SetTransformations(
		glm::vec3(baseWidth, height, baseWidth),
		0.0f, 0.0f, 0.0f,
		glm::vec3(x, height / 2.0f, z));

	SetShaderTexture("stone");
	SetShaderMaterial("stone");

	// tile the stone blocks based on the pyramid's size, so a big
	// pyramid shows more rows of blocks instead of bigger blocks
	SetTextureUVScale(baseWidth / 3.0f, height / 1.5f);
	m_basicMeshes->DrawPyramid4Mesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes. The scene
 *  recreates a desert at sunset: two pyramids, two palm
 *  trees, a sand floor, a sky backdrop, and the setting sun.
 ***********************************************************/
void SceneManager::RenderScene()
{
	/*** DESERT FLOOR (plane) ***/
	/******************************************************************/
	SetTransformations(
		glm::vec3(20.0f, 1.0f, 10.0f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, 0.0f, 0.0f));

	SetShaderTexture("sand");
	SetShaderMaterial("sand");
	// tile the sand 4 times across and 2 times deep to match the
	// plane's 20 x 10 size, so the ripples stay at a natural scale
	SetTextureUVScale(4.0f, 2.0f);
	m_basicMeshes->DrawPlaneMesh();

	/*** PYRAMIDS ***/
	/******************************************************************/
	// large pyramid back left, smaller pyramid back right,
	// matching the layout of the original 2D image
	DrawPyramid(-3.5f, -2.0f, 6.0f, 4.5f);
	DrawPyramid(4.0f, -3.0f, 3.5f, 2.6f);

	/*** PALM TREES ***/
	/******************************************************************/
	// one full size tree in front, and a smaller one farther back
	// so the scene has some depth
	DrawPalmTree(1.5f, 2.5f, 1.0f);
	DrawPalmTree(-7.0f, 1.0f, 0.7f);

	/*** SKY AND SUN (unlit) ***/
	/******************************************************************/
	// The sky and sun are light sources themselves, so they are drawn
	// with lighting turned off. That way they show their full color
	// instead of being shaded by the scene lights.
	m_pShaderManager->setBoolValue(g_UseLightingName, false);

	// SKY BACKDROP (plane): stood up on its edge behind the scene
	SetTransformations(
		glm::vec3(20.0f, 1.0f, 8.0f),
		90.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, 8.0f, -6.0f));
	// dusky purple evening sky
	SetShaderColor(0.45f, 0.25f, 0.35f, 1.0f);
	m_basicMeshes->DrawPlaneMesh();

	// SUN (sphere): low on the horizon behind the large pyramid,
	// lined up with the direction of the directional light
	SetTransformations(
		glm::vec3(1.2f, 1.2f, 1.2f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(-8.0f, 3.0f, -5.5f));
	// bright orange sunset color
	SetShaderColor(1.0f, 0.6f, 0.2f, 1.0f);
	m_basicMeshes->DrawSphereMesh();

	// turn lighting back on for the next frame
	m_pShaderManager->setBoolValue(g_UseLightingName, true);
}
